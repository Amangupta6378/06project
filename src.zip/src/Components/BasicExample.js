import Accordion from "react-bootstrap/Accordion";

function BasicExample() {
  // const male = Data.filter((item))
  return (
    <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0">
        <Accordion.Header>Gender</Accordion.Header>
        <Accordion.Body>
          <p>Male</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Female</p>
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>category</Accordion.Header>
        <Accordion.Body className="">
          <p>T-shirt</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Vest</p>
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header>Size</Accordion.Header>
        <Accordion.Body>
          <p>X</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>M</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>L</p>
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header>Color</Accordion.Header>
        <Accordion.Body className="">
          <p>Red</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Black</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Blue</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Yellow</p>
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="4">
        <Accordion.Header>Brand</Accordion.Header>
        <Accordion.Body className="">
          <p>Nike</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Addidas</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Gucci</p>
        </Accordion.Body>
        <Accordion.Body>
          <p>Polo</p>
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="5">
        <Accordion.Header>Design</Accordion.Header>
      </Accordion.Item>
    </Accordion>
  );
}

export default BasicExample;
