import React from 'react'

const Box = () => {
  return (
    <div>Box</div>
  )
}

export default Box;